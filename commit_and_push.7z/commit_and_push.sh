#!/bin/bash
# commit_and_push.sh - add, commit, and push in one step
git add . && git add -u . && git commit -m "up" && git push